## Integrated DeFi Protocols
AAVE, Pendle, Maker

## About yield.house
yield.house is a platform that helps you find the yield opportunities. We provide a curated list of all the best yield opportunities in the market.
The platform is built on top of the Privy protocol, which allows you to create a wallet through your social network account.
yield.house has a 0% fee policy, we don't charge any fee for using our platform.


## Risk Framework

Coming soon.

